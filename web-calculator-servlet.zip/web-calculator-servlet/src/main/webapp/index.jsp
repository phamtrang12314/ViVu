<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Calculator</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        form { max-width: 360px; display: grid; gap: 12px; }
        input, select, button { padding: 9px; font: inherit; }
        .error { color: #b00020; font-weight: bold; }
    </style>
</head>
<body>
<h1>Calculator Servlet</h1>

<% if (request.getAttribute("error") != null) { %>
    <p class="error"><%= request.getAttribute("error") %></p>
<% } %>

<form method="post" action="${pageContext.request.contextPath}/calculator">
    <label>
        So a
        <input type="number" step="any" name="a" required>
    </label>

    <label>
        Phep tinh
        <select name="op">
            <option value="add">Cong</option>
            <option value="sub">Tru</option>
            <option value="mul">Nhan</option>
            <option value="div">Chia</option>
        </select>
    </label>

    <label>
        So b
        <input type="number" step="any" name="b" required>
    </label>

    <button type="submit">Tinh</button>
</form>
</body>
</html>
