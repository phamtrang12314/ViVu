<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Result</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .result { font-size: 24px; font-weight: bold; }
    </style>
</head>
<body>
<h1>Ket qua</h1>
<p>A = ${a}</p>
<p>B = ${b}</p>
<p>Phep tinh = ${op}</p>
<p class="result">Ket qua = ${result}</p>
<p><a href="${pageContext.request.contextPath}/calculator">Lam lai</a></p>
</body>
</html>
