# Web Calculator Servlet

Mau de web co form JSP gui len Servlet bang POST.

## Chay trong IntelliJ

1. Open project nay bang IntelliJ.
2. Maven reload neu IntelliJ hoi.
3. Add Tomcat 10/11 trong Settings > Build, Execution, Deployment > Application Servers.
4. Run > Edit Configurations > Tomcat Server > Local.
5. Deployment > add `web-calculator-servlet:war exploded`.
6. Application context: `/web-calculator-servlet`.
7. Mo: `http://localhost:8080/web-calculator-servlet/calculator`.

## Can nho

- JSP la giao dien.
- Servlet nhan request.
- `request.getParameter("a")` lay du lieu tu form.
- `request.setAttribute(...)` day ket qua sang JSP.
- `forward(...)` chuyen noi bo sang trang ket qua.
