# REST Basic API

Mau de REST API co ca tinh cong/tru/nhan/chia va CRUD san pham trong bo nho.

## Chay trong IntelliJ

1. Open project nay bang IntelliJ.
2. Maven reload.
3. Add Tomcat 10/11.
4. Run > Edit Configurations > Tomcat Server > Local.
5. Deployment > add `rest-basic-api:war exploded`.
6. Application context: `/rest-basic-api`.
7. Base URL: `http://localhost:8080/rest-basic-api/api`.

## Test nhanh

Mo file `rest-basic.http` trong IntelliJ va bam nut run ben canh tung request.

## Can nho

- `@ApplicationPath("/api")` tao duong dan goc.
- `@Path("/products")` tao endpoint.
- `@GET` doc du lieu.
- `@POST` them moi.
- `@PUT` cap nhat.
- `@DELETE` xoa.
- `@PathParam("id")` lay bien tren URL.
